const sinon = require('sinon');
const createSearchBox = require('../components/search-box');
const expect = require('./expect');
const events = require('../events');

describe('moviedb.SearchBox', () => {
  it('createSearchBox throws an exception if container does not have input field with .search-box__input classname', async () => {
    setupDocument(`
    <div class="search-box" data-search-box></div>
    `);

    const dispatcher = sinon.stub();

    expect(
      createSearchBox.bind(
        createSearchBox,
        global.document.querySelector('[data-search-box]'),
        dispatcher
      )
    ).to.throw('Input element was not found');
  });

  it('search box sends SEARCH_BOX_TEXT_CHANGED event on input change', async () => {
    setupDocument(`
    <div class="search-box" data-search-box>
      <input type="search" class="search-box__input" value="text" />
    </div>
    `);

    const dispatcher = {
      dispatch: sinon.spy(),
    };

    createSearchBox(
      global.document.querySelector('[data-search-box]'),
      dispatcher
    );

    var evt = global.document.createEvent('HTMLEvents');
    evt.initEvent('input', false, true);
    global.document.querySelector('.search-box__input').dispatchEvent(evt);

    expect(dispatcher.dispatch).to.have.been.calledWith(
      events.SEARCH_BOX_TEXT_CHANGED,
      { query: 'text' }
    );
  });
});
