const jsdom = require('jsdom');
const { JSDOM } = jsdom;

let container;

/**
 * Set up a fresh document and window and expose them globally for easy access.
 */
beforeEach('set up jsdom', function() {
  global.dom = new JSDOM('<div id="container"></div>', {
    QuerySelector: true,
  });
  global.window = global.dom.window;
  global.document = global.dom.window.document;
  container = global.document.querySelector('#container');
});

global.setupDocument = html => {
  container.innerHTML = html;
  return container;
};

afterEach('clean up jsdom', function() {
  container.innerHTML = '';
  global.window = undefined;
  global.document = undefined;
});
