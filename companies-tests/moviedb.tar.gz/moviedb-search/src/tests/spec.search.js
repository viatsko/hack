const sinon = require('sinon');
const Search = require('../lib/search');
const expect = require('./expect');

describe('moviedb.Search', () => {
  let oldFetch;

  beforeEach(function() {
    // Temporarily wap global fetch for a stub
    oldFetch = global.fetch;
    global.fetch = sinon.stub();
    global.fetch.returns(
      Promise.resolve({
        json() {
          return Promise.resolve({
            results: [],
          });
        },
      })
    );
  });

  afterEach(function() {
    global.fetch = oldFetch;
  });

  it('search.byQuery sends a request and gets json response with results array within', async () => {
    const search = new Search('RANDOM_API_KEY');
    const resultsJson = await search.byQuery('RANDOM_QUERY');
    expect(global.fetch).to.be.calledOnce;
    expect(resultsJson).to.eql({ results: [] });
  });
});
