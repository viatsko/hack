const sinon = require('sinon');
const createApp = require('../components/app-factory');
const expect = require('./expect');
const events = require('../events');

describe('moviedb.AppFactory', () => {
  it('createApp throws an exception if search box component is missing within a container', async () => {
    setupDocument(`
    <div class="container" data-app>
      <div class="results-list" data-results-list>
        <ul class="results-list__list">
          <li>No results.</li>
        </ul>
      </div>
    </div>
    `);

    const dispatcher = sinon.stub();

    expect(
      createApp.bind(createApp, global.document.querySelector('[data-app]'))
    ).to.throw('Element for search box was not found');
  });

  it('createApp throws an exception if results list component is missing within a container', async () => {
    setupDocument(`
    <div class="container" data-app>
      <div class="search-box" data-search-box>
        What do you want to see today? <input type="search" class="search-box__input" placeholder="over 10,000 movies" />
      </div>
    </div>
    `);

    const dispatcher = sinon.stub();

    expect(
      createApp.bind(createApp, global.document.querySelector('[data-app]'))
    ).to.throw('Element for results list was not found');
  });
});
