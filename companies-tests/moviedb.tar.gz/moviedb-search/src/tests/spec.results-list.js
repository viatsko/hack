const sinon = require('sinon');
const Dispatcher = require('../lib/dispatcher');
const createResultsList = require('../components/results-list');
const expect = require('./expect');
const events = require('../events');

describe('moviedb.ResultsList', () => {
  it('createResultsList throws an exception if container does not list element with .results-list__list classname', async () => {
    setupDocument(`
    <div class="results-list" data-results-list></div>
    `);

    const dispatcher = sinon.stub();

    expect(
      createResultsList.bind(
        createResultsList,
        global.document.querySelector('[data-results-list]'),
        dispatcher
      )
    ).to.throw('No results list element.');
  });

  it('results list listens to RESULTS_CHANGED event and changes html according to payload', async () => {
    setupDocument(`
    <div class="results-list" data-results-list>
      <ul class="results-list__list">
        <li>No results.</li>
      </ul>
    </div>
    `);

    const dispatcher = new Dispatcher();

    createResultsList(
      global.document.querySelector('[data-results-list]'),
      dispatcher
    );

    dispatcher.dispatch(events.RESULTS_CHANGED, [
      {
        original_title: 'test title',
        poster_path: 'test poster path',
        overview: 'test overview',
      },
      {
        original_title: 'test title 2',
        poster_path: 'test poster path 2',
        overview: 'test overview 2',
      },
      {
        original_title: 'test title 3',
        poster_path: 'test poster path 3',
        overview: 'test overview 3',
      },
    ]);

    expect(global.document.querySelectorAll('.results-item').length === 3).to.be
      .true;
  });
});
