const createApp = require('./components/app-factory');

createApp(document.querySelector('[data-app]'));
