const createSearchBox = require('./search-box');
const createResultsList = require('./results-list');
const Dispatcher = require('../lib/dispatcher');
const Search = require('../lib/search');
const events = require('../events');

module.exports = function createApp(container) {
  const dispatcher = new Dispatcher();
  const search = new Search(window.API_KEY);

  const searchBoxEl = container.querySelector('[data-search-box]');

  if (!searchBoxEl) {
    throw new Error('Element for search box was not found');
  }

  const resultsListEl = container.querySelector('[data-results-list]');

  if (!resultsListEl) {
    throw new Error('Element for results list was not found');
  }

  createSearchBox(searchBoxEl, dispatcher);
  createResultsList(resultsListEl, dispatcher);

  // TODO move it to a separate module
  dispatcher.on(events.SEARCH_BOX_TEXT_CHANGED, async payload => {
    const { query } = payload;
    const searchResultsJson = await search.byQuery(query);
    const { results } = searchResultsJson;
    dispatcher.dispatch(events.RESULTS_CHANGED, results);
  });
};
