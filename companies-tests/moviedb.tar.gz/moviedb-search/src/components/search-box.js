const events = require('../events');

module.exports = function createSearchBox(container, dispatcher) {
  const inputEl = container.querySelector('.search-box__input');

  if (!inputEl) {
    throw new Error('Input element was not found');
  }

  inputEl.addEventListener('input', function() {
    dispatcher.dispatch(events.SEARCH_BOX_TEXT_CHANGED, {
      query: this.value,
    });
  });
};
