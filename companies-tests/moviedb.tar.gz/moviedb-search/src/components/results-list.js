const events = require('../events');

module.exports = function createResultsList(container, dispatcher) {
  const resultsListEl = container.querySelector('.results-list__list');

  if (!resultsListEl) {
    throw new Error('No results list element.');
  }

  dispatcher.on(events.RESULTS_CHANGED, results => {
    resultsListEl.innerHTML = results
      .map(
        result => `
      <li class="results-item">
        <h4>${result.original_title}</h4>
        ${
          result.poster_path
            ? `<img src="https://image.tmdb.org/t/p/w185/${
                result.poster_path
              }" />`
            : ''
        }
        <p>${result.overview}</p>
      </li>
    `
      )
      .join('');
  });
};
