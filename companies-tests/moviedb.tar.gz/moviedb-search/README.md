# moviedb-search

## Overview

This is what I've hacked during ~4 hours. Not much of functionality, but was aiming for showing my approach to development. You can check working application by opening index.html; and you can check the test suite which uses chai, mocha and sinon at src/tests directory by running yarn run test:unit command.

Thoughts on improvements (if I've had more time):
0) Didn't have time at all to do a useful functionality piece, e. g. pagination
1) Needs functional tests - per example to check how the app created by app-factory works overall
2) CSS could've been organized better and built using WebPack and PostCSS
3) Dispatcher test skipped saving time for implementing basic functionality bits
4) Put fetch + display logic in app-factory, should be in a separate module, but I've run out of time for this exercise

## Running a project

Openning `index.html` should be enough since javascript is already built (dist/bundle.js).

## Running tests

```sh
yarn
yarn run test:unit
```

or (in case of npm)

```sh
npm install
npm run test:unit
```
